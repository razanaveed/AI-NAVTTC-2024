"""
It is my module
"""


def my_func(x, y):
    """
    It is my function
    """
    for i in range(1000):
        x += 1
        y += 1
    return x + y
